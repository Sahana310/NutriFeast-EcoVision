"""Offline deterministic safety-first disposal planner, with optional local Ollama prose."""
import os, json, urllib.request
from disposal_engine import advice, ALIASES

def create_action_plan(detections, semantic, confirmed=False):
    labels=[str(x.get('label','')).lower().strip() for x in detections if x.get('label')]
    organic={'fruit peels','vegetable scraps','eggshells','cooked food'}
    packaging={'plastic','paper','glass','metal'}
    kinds={ALIASES.get(x,x) for x in labels}
    possible_organic=any('food waste' in str(x.get('label','')).lower() or x.get('category')=='organic' for x in semantic)
    has_organic=bool(kinds & organic) or possible_organic
    has_pack=bool(kinds & packaging)
    steps=[]
    def add(title,body,stream,source):steps.append({'title':title,'instruction':body,'stream':stream,'source':source})
    add('Inspect and separate materials','Spread out the waste safely. Keep organic scraps apart from wrappers, bottles, paper, metal and glass. Do not handle sharps or unknown hazardous waste bare-handed.','Preparation','General precaution')
    if has_organic:
        add('Collect food scraps','Remove visible plastic, stickers and other non-organic contaminants. Place accepted food scraps in a covered wet-waste bin; compost only where locally permitted.','Wet / organic','Confirmed item' if confirmed else 'AI suggestion — verify')
    if has_pack:
        add('Remove and sort packaging','Empty packaging and separate by actual material. Check contamination and local recycler acceptance; do not assume all wrappers are recyclable.','Dry / recyclable after verification','Confirmed item' if confirmed else 'AI suggestion — verify')
    if not has_organic and not has_pack:
        add('Identify waste manually','The image did not provide dependable material-level identification. Select the visible waste items below before assigning a bin.','Manual review','Unknown')
    add('Handle remaining mixed or contaminated waste','Keep contaminated residuals and unidentifiable materials separate from clean recycling. Follow local residual-waste collection rules.','Residual / review','General precaution')
    return {'steps':steps,'detected_labels':labels,'status':'User confirmed' if confirmed else 'Provisional — inspect items','note':'AI labels and CLIP similarities do not prove material identity. Verify every disposal stream.'}

def ask_advisor(question,items):
    question=question.strip()
    if not question:return {'answer':'Enter a question about waste segregation.','mode':'offline rules'}
    safe=[str(i)[:80] for i in items[:30]]
    # Optional local Ollama: no cloud API; fall back to deterministic offline rules.
    if os.environ.get('ECOVISION_OLLAMA','0')=='1':
        prompt=('You are a waste segregation assistant. Never invent image detections or local recycling rules. '
                'Use only these user-confirmed items: '+', '.join(safe)+'. Question: '+question+
                '. Provide numbered practical steps and state when verification is needed.')
        try:
            req=urllib.request.Request('http://127.0.0.1:11434/api/generate',data=json.dumps({'model':os.environ.get('ECOVISION_LLM_MODEL','llama3.2:3b'),'prompt':prompt,'stream':False}).encode(),headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(req,timeout=35) as r:
                data=json.load(r)
            return {'answer':str(data.get('response','')).strip(),'mode':'local Ollama'}
        except Exception:pass
    keys=['plastic','food','paper','glass','metal','battery','egg','fruit','vegetable']
    matched=[k for k in keys if k in question.lower()]
    chosen=safe or matched or ['mixed']
    lines=[]
    for i in chosen[:8]:
        a=advice(i if i not in ('food','egg','fruit','vegetable','battery') else {'food':'cooked food','egg':'eggshells','fruit':'fruit peels','vegetable':'vegetable scraps','battery':'hazardous'}[i])
        lines.append(f"{a['item']}: {a['steps']} Caution: {a['caution']}")
    return {'answer':'\n'.join(lines)+'\nConfirm materials and follow your local collection rules.','mode':'offline rules'}
