"""Conservative waste disposal advisor. Rules are guidance, not material verification."""
CATALOG = {
 'fruit peels':('Organic','Separate fruit peels from plastic and other packaging. Compost in an accepted food-scrap stream or send to authorized wet-waste collection.','Do not compost with stickers or plastic bags.'),
 'vegetable scraps':('Organic','Remove packaging; collect vegetable offcuts in a covered wet-waste bin. Compost where accepted or use municipal organic collection.','Keep non-organic contaminants out.'),
 'eggshells':('Organic','Place crushed eggshells in accepted organic-waste or compost collection.','Confirm local compost rules.'),
 'cooked food':('Organic / facility dependent','Collect cooked leftovers separately in a sealed wet-waste container. Send to an approved food-waste processor where available.','Home compost systems may not accept cooked/oily foods.'),
 'paper':('Recycling / verify','Separate clean, dry paper and cardboard; flatten and send to an authorized dry-waste recycler.','Greasy or food-soiled paper may not be recyclable.'),
 'plastic':('Recycling / verify','Empty and clean the item when required. Check the plastic type and local collection rules before putting it in dry recyclables.','Multilayer wrappers and contaminated plastics may not be accepted.'),
 'metal':('Recycling / verify','Empty cans and segregate clean metal from food waste; send to dry-waste recycling.','Watch for sharp edges.'),
 'glass':('Recycling / verify','Separate intact glass bottles/jars and follow local glass collection requirements.','Wrap broken glass securely; do not put it loose in recycling.'),
 'mixed':('Mixed / separate','Sort visible food residues into wet waste; isolate clean dry packaging, metal and glass. Place unrecoverable contaminated residuals in the appropriate local residual stream.','Never put an entire mixed pile into the recycling bin.'),
 'hazardous':('Special handling','Keep batteries, chemicals, sharps and e-waste out of wet/dry bins. Use designated authorized collection.','Do not handle unknown hazardous material without protection.'),
 'unknown':('Manual verification','Inspect the item, identify its material and contamination, then choose a local disposal stream.','A photograph alone cannot establish material or recyclability.')
}
ALIASES={'apple':'fruit peels','banana':'fruit peels','orange':'fruit peels','carrot':'vegetable scraps','broccoli':'vegetable scraps','sandwich':'cooked food','pizza':'cooked food','cake':'cooked food','donut':'cooked food','bottle':'plastic','cup':'unknown','bowl':'unknown','fork':'unknown','knife':'unknown','spoon':'unknown','banana peel':'fruit peels','orange peel':'fruit peels','apple core':'fruit peels','fruit scraps':'fruit peels','vegetable scraps':'vegetable scraps','carrot pieces':'vegetable scraps','leafy vegetable scraps':'vegetable scraps','onion skins':'vegetable scraps','eggshells':'eggshells','cooked rice leftovers':'cooked food','bread leftovers':'cooked food','mixed food scraps':'mixed','food waste':'mixed','plastic bottle':'plastic','plastic wrapper':'plastic','metal can':'metal','cardboard packaging':'paper','paper waste':'paper','glass bottle':'glass','food container':'unknown','compost pile':'unknown','ordinary household objects':'unknown'}
def advice(item):
 name=str(item).strip().lower(); key=ALIASES.get(name,name if name in CATALOG else 'unknown')
 category,steps,caution=CATALOG[key]
 return {'item':item,'type':key,'category':category,'steps':steps,'caution':caution,'requires_verification':True}
def plan(detections,semantic):
 # Object detections are predictions; semantic entries are candidate labels, not confirmed objects.
 items=[]; seen=set()
 for d in detections:
  label=d.get('label','unknown'); key=ALIASES.get(label,'unknown')
  if key not in seen and key!='unknown':items.append({**advice(label),'source':'Object detection (verify)'});seen.add(key)
 # CLIP similarity is not evidence of a specific waste item; do not auto-assert candidates.
 if not items:items=[{**advice('mixed'),'source':'General mixed-waste precaution'}]
 return items
