import os, json, sqlite3, uuid, io, csv
from datetime import datetime, timezone
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file
from PIL import Image, ImageDraw, ImageFont, ImageOps
from disposal_engine import plan, advice, CATALOG
from smart_advisor import create_action_plan

BASE=Path(__file__).resolve().parent
DB=BASE/'ecovision.db'
UPLOAD=BASE/'uploads'; UPLOAD.mkdir(exist_ok=True)
app=Flask(__name__); app.config['MAX_CONTENT_LENGTH']=10*1024*1024
_model=None
FOOD={'apple','banana','orange','carrot','broccoli','sandwich','pizza','hot dog','donut','cake'}
PACK={'bottle','cup','wine glass','bowl','fork','knife','spoon'}
# Conservative confidence threshold reduces misleading labels, but does not guarantee accuracy.
MIN_CONFIDENCE=0.55
MIN_BOX_AREA_RATIO=0.002
def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
 with db() as c:
  c.execute('CREATE TABLE IF NOT EXISTS scans(id TEXT PRIMARY KEY, created TEXT, image TEXT, annotated TEXT, detections TEXT, category TEXT)')
  c.execute('CREATE TABLE IF NOT EXISTS rescue(id TEXT PRIMARY KEY, created TEXT, food TEXT, quantity TEXT, prepared TEXT, storage TEXT, location TEXT, notes TEXT, status TEXT)')
init()
def classify(names, semantic):
 if semantic:
  categories={x['category'] for x in semantic}
  if 'organic' in categories and 'recyclable_verify' in categories:
   return 'Mixed waste / verify','Both organic and packaging-like material are suggested. Separate manually; verify actual materials and contamination.'
  if 'organic' in categories:return 'Potential organic / verify','The image resembles organic food scraps. Visual similarity is not proof of material, freshness or compostability; confirm manually.'
  if 'recyclable_verify' in categories:return 'Packaging / verify','Potential packaging detected. Verify material and cleanliness before recycling.'
 if names:return 'Objects / manual review','General objects detected. Verify their waste category manually.'
 return 'Manual review','No reliable waste identification. Try a clearer image or record items manually.'
@app.route('/')
def index(): return render_template('index.html')
@app.get('/api/health')
def health(): return jsonify(status='ok',model='YOLO11m + optional CLIP')
@app.post('/api/analyze')
def analyze():
 f=request.files.get('image')
 if not f:return jsonify(error='Choose an image first.'),400
 try:
  raw=f.read(); temp=Image.open(io.BytesIO(raw)); temp.verify()
  im=ImageOps.exif_transpose(Image.open(io.BytesIO(raw))).convert('RGB')
  if im.width*im.height>18000000:return jsonify(error='Image is too large.'),400
  ident=uuid.uuid4().hex[:12]; original=f'{ident}.jpg'; annotated=f'{ident}_annotated.jpg'; im.save(UPLOAD/original,quality=90)
  from vision_engine import analyze_image
  detected,semantic,warning=analyze_image(im,use_clip=request.form.get('clip','true')!='false')
  canvas=im.copy(); draw=ImageDraw.Draw(canvas)
  for item in detected:
   x1,y1,x2,y2=map(int,item['box']); color='#BEF264'
   draw.rectangle((x1,y1,x2,y2),outline=color,width=max(3,im.width//250))
   caption=f"{item['label']} {item['confidence']:.0%}"
   top=max(0,y1-18); draw.rectangle((x1,top,x1+min(len(caption)*9+10,im.width-x1),top+18),fill='#0D241B')
   draw.text((x1+4,top+2),caption,fill='white')
  canvas.save(UPLOAD/annotated,quality=90)
  category,guidance=classify([d['label'] for d in detected],semantic)
  disposal=plan(detected,semantic)
  action_plan=create_action_plan(detected,semantic)
  created=datetime.now(timezone.utc).isoformat()
  # Persist both streams with source attribution. Region classifications are NOT object boxes.
  all_results=detected+semantic
  with db() as c:c.execute('INSERT INTO scans VALUES(?,?,?,?,?,?)',(ident,created,original,annotated,json.dumps(all_results),category))
  return jsonify(id=ident,created=created,image=f'/uploads/{original}',annotated=f'/uploads/{annotated}',detections=detected,semantic=semantic,category=category,guidance=guidance,disposal=disposal,action_plan=action_plan,warning=warning,model_note='YOLO11m finds general objects. CLIP provides region-level visual-similarity candidates, not validated object detections. Mixed waste still needs manual verification.')
 except Exception as e:
  app.logger.exception('Inference failed')
  return jsonify(error=f'Analysis unavailable: {str(e)[:250]}'),503
@app.get('/uploads/<filename>')
def uploads(filename):
 from flask import send_from_directory
 return send_from_directory(UPLOAD,filename)
@app.post('/api/action-plan')
def action_plan_api():
 d=request.get_json(silent=True) or {}
 items=d.get('items',[])
 if not isinstance(items,list) or len(items)>40:return jsonify(error='Maximum 40 items'),400
 verified=[{'label':str(i)[:90], 'source':'User confirmed'} for i in items]
 return jsonify(create_action_plan(verified,[],confirmed=True))
@app.post('/api/advisor/chat')
def advisor_chat():
 d=request.get_json(silent=True) or {}
 question=str(d.get('question',''))[:500]
 items=d.get('items',[])
 if not isinstance(items,list):items=[]
 from smart_advisor import ask_advisor
 return jsonify(ask_advisor(question,items))
@app.delete('/api/rescue/<ident>')
def delete_rescue(ident):
 with db() as c:
  cur=c.execute('DELETE FROM rescue WHERE id=?',(ident,))
  if cur.rowcount==0:return jsonify(error='Record not found'),404
 return jsonify(ok=True)
@app.get('/api/disposal/catalog')
def disposal_catalog():
 return jsonify([{'id':k,**advice(k)} for k in CATALOG])
@app.post('/api/disposal/advise')
def disposal_advise():
 d=request.get_json(silent=True) or {}
 raw=d.get('items',[])
 if not isinstance(raw,list) or len(raw)>30:return jsonify(error='Provide up to 30 items.'),400
 return jsonify(items=[advice(str(x)[:80]) for x in raw])
@app.get('/api/scans')
def scans():
 with db() as c: rows=c.execute('SELECT * FROM scans ORDER BY created DESC').fetchall()
 return jsonify([{**dict(r),'detections':json.loads(r['detections']),'image':'/uploads/'+r['image'],'annotated':'/uploads/'+r['annotated']} for r in rows])
@app.delete('/api/scans/<ident>')
def delscan(ident):
 with db() as c:
  r=c.execute('SELECT image,annotated FROM scans WHERE id=?',(ident,)).fetchone()
  if not r:return jsonify(error='Not found'),404
  c.execute('DELETE FROM scans WHERE id=?',(ident,))
 for fn in [r['image'],r['annotated']]: (UPLOAD/fn).unlink(missing_ok=True)
 return jsonify(ok=True)
@app.get('/api/analytics')
def analytics():
 with db() as c:
  rows=c.execute('SELECT category,detections,created FROM scans').fetchall(); resc=c.execute('SELECT COUNT(*) FROM rescue').fetchone()[0]
 categories={}; objects=0; days={}
 for r in rows:
  categories[r['category']]=categories.get(r['category'],0)+1
  objects+=len(json.loads(r['detections'])); day=r['created'][:10]; days[day]=days.get(day,0)+1
 return jsonify(scans=len(rows),objects=objects,rescue=resc,categories=categories,days=days)
@app.route('/api/rescue',methods=['GET','POST'])
def rescue():
 if request.method=='GET':
  with db() as c: return jsonify([dict(x) for x in c.execute('SELECT * FROM rescue ORDER BY created DESC')])
 d=request.get_json(silent=True) or {}
 if not str(d.get('food','')).strip(): return jsonify(error='Food name required'),400
 ident=uuid.uuid4().hex[:12]; vals=[ident,datetime.now(timezone.utc).isoformat()]+[str(d.get(k,''))[:400] for k in ['food','quantity','prepared','storage','location','notes']]+['Available']
 with db() as c:c.execute('INSERT INTO rescue VALUES(?,?,?,?,?,?,?,?,?)',vals)
 return jsonify(id=ident,ok=True),201
@app.patch('/api/rescue/<ident>')
def update_rescue(ident):
 status=(request.get_json(silent=True) or {}).get('status')
 if status not in ('Available','Collected','Discarded'):return jsonify(error='Invalid status'),400
 with db() as c:
  cur=c.execute('UPDATE rescue SET status=? WHERE id=?',(status,ident))
  if cur.rowcount==0:return jsonify(error='Record not found'),404
 return jsonify(ok=True)
@app.get('/api/export')
def export():
 with db() as c: rows=c.execute('SELECT id,created,category,detections FROM scans ORDER BY created DESC').fetchall()
 out=io.StringIO(); writer=csv.writer(out); writer.writerow(['ID','Timestamp','Category','Detections'])
 for r in rows:writer.writerow(list(r))
 return send_file(io.BytesIO(out.getvalue().encode('utf-8-sig')),mimetype='text/csv',as_attachment=True,download_name='ecovision_scans.csv')
@app.errorhandler(413)
def large(_):return jsonify(error='Image must be smaller than 10 MB'),413
if __name__=='__main__':app.run(debug=True,port=5000)
