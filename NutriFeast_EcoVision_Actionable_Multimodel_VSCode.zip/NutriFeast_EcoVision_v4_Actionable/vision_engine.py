"""Two complementary, real models: YOLO11m localization + optional CLIP tile recognition.
Neither is trained to guarantee individual recognition in dense mixed kitchen scraps.
"""
import io, math
from functools import lru_cache
from PIL import Image, ImageDraw

LABELS = [
 ('banana peel','organic'),('orange peel','organic'),('apple core','organic'),('vegetable scraps','organic'),
 ('carrot pieces','organic'),('leafy vegetable scraps','organic'),('onion skins','organic'),
 ('eggshells','organic'),('fruit scraps','organic'),('cooked rice leftovers','organic'),
 ('bread leftovers','organic'),('mixed food scraps','organic'),('food waste','organic'),
 ('plastic bottle','recyclable_verify'),('plastic wrapper','recyclable_verify'),
 ('metal can','recyclable_verify'),('cardboard packaging','recyclable_verify'),
 ('paper waste','recyclable_verify'),('glass bottle','recyclable_verify'),
 ('food container','manual_review'),('compost pile','organic'),('ordinary household objects','manual_review')
]
PROMPTS = [f'a close-up photo of {name}' for name,_ in LABELS]

@lru_cache(maxsize=1)
def yolo_model():
 from ultralytics import YOLO
 return YOLO('yolo11m.pt')

@lru_cache(maxsize=1)
def clip_model():
 import open_clip, torch
 model,_,preprocess=open_clip.create_model_and_transforms('ViT-B-32',pretrained='laion2b_s34b_b79k',device='cpu')
 tokenizer=open_clip.get_tokenizer('ViT-B-32')
 model.eval()
 with torch.inference_mode():
  texts=tokenizer(PROMPTS)
  features=model.encode_text(texts)
  features=features/features.norm(dim=-1,keepdim=True)
 return model,preprocess,features

def analyze_image(im, use_clip=True):
 import numpy as np
 image=np.array(im.convert('RGB'))
 result=yolo_model().predict(source=image,conf=0.30,iou=0.45,imgsz=960,max_det=60,verbose=False)[0]
 det=[]
 for box in result.boxes:
  name=result.names[int(box.cls[0])]
  score=float(box.conf[0]); xy=[round(float(v),1) for v in box.xyxy[0].tolist()]
  if (xy[2]-xy[0])*(xy[3]-xy[1])<0.0015*im.width*im.height:continue
  det.append({'label':name,'confidence':round(score,3),'box':xy,'source':'YOLO11m','kind':'object'})
 # Optional open-vocabulary object localization. Requires transformers + downloaded weights.
 # This model is independent from CLIP and can localize prompted waste categories.
 warning=None
 try:
  if __import__('os').environ.get('ECOVISION_GROUNDING_DINO','0')=='1':
   det.extend(open_vocabulary_detect(im))
 except Exception as exc:
  warning='Optional open-vocabulary detector unavailable: '+str(exc)[:130]
 # Remove highly overlapping duplicate boxes with identical labels.
 dedup=[]
 for item in sorted(det,key=lambda x:x['confidence'],reverse=True):
  if not any(item['label']==p['label'] and box_iou(item['box'],p['box'])>0.5 for p in dedup):dedup.append(item)
 det=dedup[:45]
 semantic=[]
 if use_clip:
  try:
   import torch
   model,preprocess,features=clip_model()
   w,h=im.size
   crops=[('Whole image',(0,0,w,h))]
   # 2x2 overlapping patches give mixed waste a chance to be recognized at region level.
   for yi in range(2):
    for xi in range(2):
     x0=int(xi*w*0.35);y0=int(yi*h*0.35)
     crops.append((f'Region {yi*2+xi+1}',(x0,y0,min(w,x0+int(w*0.65)),min(h,y0+int(h*0.65)))))
   batch=torch.stack([preprocess(im.crop(bounds)) for _,bounds in crops])
   with torch.inference_mode():
    image_features=model.encode_image(batch)
    image_features=image_features/image_features.norm(dim=-1,keepdim=True)
    logits=(100*image_features@features.T).softmax(dim=-1)
   for (region,bounds),probs in zip(crops,logits):
    val,idx=probs.max(dim=0);score=float(val); name,category=LABELS[int(idx)]
    # These are relative candidate scores among supplied labels, NOT calibrated probabilities.
    if score>=0.16:
     semantic.append({'label':name,'confidence':round(score,3),'box':list(bounds),'source':'CLIP candidate','kind':'semantic','category':category,'region':region})
  except Exception as exc:
   warning=f'Optional CLIP model unavailable ({str(exc)[:140]}). YOLO detections are still available.'
 return det,semantic,warning


def box_iou(a,b):
 x1=max(a[0],b[0]);y1=max(a[1],b[1]);x2=min(a[2],b[2]);y2=min(a[3],b[3]); inter=max(0,x2-x1)*max(0,y2-y1)
 aa=max(0,a[2]-a[0])*max(0,a[3]-a[1]);bb=max(0,b[2]-b[0])*max(0,b[3]-b[1]);return inter/(aa+bb-inter+1e-6)

@lru_cache(maxsize=1)
def grounding_detector():
 from transformers import pipeline
 return pipeline('zero-shot-object-detection',model='IDEA-Research/grounding-dino-tiny',device=-1)

def open_vocabulary_detect(im):
 labels=['plastic bottle','plastic bag','plastic food wrapper','cardboard','paper plate','metal can','glass bottle','banana peel','orange peel','eggshell','vegetable scraps','food leftovers','fruit peel','carrot','onion','leafy vegetables','food container']
 result=grounding_detector()(im,candidate_labels=labels,threshold=0.28)
 out=[]
 for x in result:
  b=x['box']; xy=[b['xmin'],b['ymin'],b['xmax'],b['ymax']]
  out.append({'label':x['label'],'confidence':round(float(x['score']),3),'box':xy,'source':'Grounding DINO (open vocabulary)','kind':'object'})
 return out
