# NutriFeast EcoVision — Actionable Multimodel Edition

WasteVision hackathon prototype. Includes **real YOLO11m**, optional **Grounding DINO Tiny** open-vocabulary localization, optional **OpenCLIP** region classification, a **deterministic offline disposal advisor**, optional local **Ollama**, interactive smart segregation, and persistent SQLite rescue records.

## Windows / VS Code

1. Extract the ZIP and open its folder in VS Code.
2. Install Python 3.11 or 3.12 and run:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py
```

3. Open http://127.0.0.1:5000 and refresh with Ctrl+F5 if replacing an older version.

The first YOLO/CLIP run downloads weights (internet needed once). CPU inference may be slow.

## Optional open-vocabulary detector (better coverage, not guaranteed accuracy)

Grounding DINO Tiny adds localized detections for prompted labels including plastic packaging, food scraps, eggshells and fruit peels. It is optional because installation and CPU inference are resource-intensive.

```powershell
.venv\Scripts\python.exe -m pip install "transformers>=4.45,<5" torch
$env:ECOVISION_GROUNDING_DINO="1"
.venv\Scripts\python.exe app.py
```

If this detector fails to load, the app falls back to YOLO + CLIP and displays a warning. Its weights must be downloaded on first use. Prompted labels are hypotheses, not proof of material.

## Optional local Ollama LLM (no cloud API)

Install Ollama separately, then download a small local model once:

```powershell
ollama pull llama3.2:3b
$env:ECOVISION_OLLAMA="1"
$env:ECOVISION_LLM_MODEL="llama3.2:3b"
.venv\Scripts\python.exe app.py
```

Without Ollama, the advisor works offline with deterministic rules and never fabricates AI detections. The LLM only explains disposal guidance; it does not inspect images.

## Demonstration

1. Scan an image with the AI Waste Scanner.
2. Review model detections and provisional disposal steps.
3. Open Smart Segregation; select **user-verified** food scraps and packaging and generate a sorting plan.
4. Ask the offline advisor how to handle mixed waste.
5. Create a Food Rescue record; change status or delete it.
6. Open Analytics and Scan History to review stored activity.

## Limitations

No pretrained general-purpose model can guarantee identifying **all** items in dense, overlapping mixed waste. CLIP similarities are not calibrated probabilities. Open-vocabulary detections may also be wrong. Material type, cleanliness, recyclability, food safety and local collection rules require confirmation. No claims of measured accuracy are made without an evaluated dataset.
